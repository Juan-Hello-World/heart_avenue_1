<!DOCTYPE html>
<html lang="en-AU">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="canonical" href="https://www.heartavenueassociation.com/www.webador.pl">
        <link rel="sitemap" type="application/xml" href="https://www.heartavenueassociation.com/sitemap.xml">
        <meta property="og:title" content="Page not found">
        <meta property="og:url" content="https://www.heartavenueassociation.com/www.webador.pl">
        <base href="https://www.heartavenueassociation.com/">
        <meta name="description" property="og:description" content="">
                <script nonce="b834adb9fe316030b0d54ffa4d90b2d7">
            
            window.JOUWWEB = window.JOUWWEB || {};
            window.JOUWWEB.application = window.JOUWWEB.application || {};
            window.JOUWWEB.application = {"backends":[{"domain":"jouwweb.nl","freeDomain":"jouwweb.site"},{"domain":"webador.com","freeDomain":"webadorsite.com"},{"domain":"webador.de","freeDomain":"webadorsite.com"},{"domain":"webador.fr","freeDomain":"webadorsite.com"},{"domain":"webador.es","freeDomain":"webadorsite.com"},{"domain":"webador.it","freeDomain":"webadorsite.com"},{"domain":"jouwweb.be","freeDomain":"jouwweb.site"},{"domain":"webador.ie","freeDomain":"webadorsite.com"},{"domain":"webador.co.uk","freeDomain":"webadorsite.com"},{"domain":"webador.at","freeDomain":"webadorsite.com"},{"domain":"webador.be","freeDomain":"webadorsite.com"},{"domain":"webador.ch","freeDomain":"webadorsite.com"},{"domain":"webador.ch","freeDomain":"webadorsite.com"},{"domain":"webador.mx","freeDomain":"webadorsite.com"},{"domain":"webador.com","freeDomain":"webadorsite.com"},{"domain":"webador.dk","freeDomain":"webadorsite.com"},{"domain":"webador.se","freeDomain":"webadorsite.com"},{"domain":"webador.no","freeDomain":"webadorsite.com"},{"domain":"webador.fi","freeDomain":"webadorsite.com"},{"domain":"webador.ca","freeDomain":"webadorsite.com"},{"domain":"webador.ca","freeDomain":"webadorsite.com"},{"domain":"webador.pl","freeDomain":"webadorsite.com"},{"domain":"webador.com.au","freeDomain":"webadorsite.com"},{"domain":"webador.nz","freeDomain":"webadorsite.com"}],"editorLocale":"en-US","editorTimezone":"America\/New_York","editorLanguage":"en","analytics4TrackingId":"G-E6PZPGE4QM","analyticsDimensions":{"app_context":"404"},"backendDomain":"www.webador.es","backendShortDomain":"webador.es","backendKey":"webador-es","freeWebsiteDomain":"webadorsite.com","noSsl":false,"build":{"reference":"b0b9a1e"},"linkHostnames":["www.jouwweb.nl","www.webador.com","www.webador.de","www.webador.fr","www.webador.es","www.webador.it","www.jouwweb.be","www.webador.ie","www.webador.co.uk","www.webador.at","www.webador.be","www.webador.ch","fr.webador.ch","www.webador.mx","es.webador.com","www.webador.dk","www.webador.se","www.webador.no","www.webador.fi","www.webador.ca","fr.webador.ca","www.webador.pl","www.webador.com.au","www.webador.nz"],"assetsUrl":"https:\/\/assets.jwwb.nl","loginUrl":"https:\/\/www.webador.es\/iniciar-sesion","publishUrl":"https:\/\/www.webador.es\/v2\/website\/8366932\/publish-proxy","adminUserOrIp":false,"currency":"EUR","hcUrl":{"add-product-variants":"https:\/\/help.webador.com\/hc\/en-us\/articles\/29426751649809","basic-vs-advanced-shipping":"https:\/\/help.webador.com\/hc\/en-us\/articles\/29426731685777","html-in-head":"https:\/\/help.webador.com\/hc\/en-us\/articles\/29426689990033","link-domain-name":"https:\/\/help.webador.com\/hc\/en-us\/articles\/29426688803345","optimize-for-mobile":"https:\/\/help.webador.com\/hc\/en-us\/articles\/29426707033617","seo":"https:\/\/help.webador.com\/hc\/en-us\/categories\/29387178511377","transfer-domain-name":"https:\/\/help.webador.com\/hc\/en-us\/articles\/29426715688209","website-not-secure":"https:\/\/help.webador.com\/hc\/en-us\/articles\/29426706659729"}};
            window.JOUWWEB.brand = {"type":"webador","name":"Webador","domain":"Webador.es","supportEmail":"soporte@webador.es"};
                    
                window.JOUWWEB = window.JOUWWEB || {};
                window.JOUWWEB.websiteRendering = {"locale":"en-AU","timezone":"America\/New_York","routes":{"api\/upload\/product-field":"\/_api\/upload\/product-field","checkout\/cart":"\/cart","payment":"\/complete-order\/:publicOrderId","payment\/forward":"\/complete-order\/:publicOrderId\/forward","public-order":"\/order\/:publicOrderId","checkout\/authorize":"\/cart\/authorize\/:gateway","wishlist":"\/wishlist"}};
                                                    window.JOUWWEB.website = {"id":8366932,"locale":"en-AU","enabled":true,"title":"Heart Avenue Association","hasTitle":true,"roleOfLoggedInUser":null,"ownerLocale":"en-US","plan":"business","freeWebsiteDomain":"webadorsite.com","backendKey":"webador-com-es","currency":"USD","defaultLocale":"en-AU","url":"https:\/\/www.heartavenueassociation.com\/","homepageSegmentId":36819356,"category":"website","isOffline":false,"isPublished":true,"locales":["en-AU"],"allowed":{"ads":false,"credits":true,"externalLinks":true,"slideshow":true,"customDefaultSlideshow":false,"hostedAlbums":true,"moderators":true,"mailboxQuota":10,"statisticsVisitors":true,"statisticsDetailed":true,"statisticsMonths":-1,"favicon":true,"password":true,"freeDomains":0,"freeMailAccounts":1,"canUseLanguages":false,"fileUpload":true,"legacyFontSize":false,"webshop":true,"products":-1,"imageText":false,"search":true,"audioUpload":true,"videoUpload":5000,"allowDangerousForms":false,"allowHtmlCode":true,"mobileBar":true,"sidebar":false,"poll":false,"allowCustomForms":true,"allowBusinessListing":true,"allowCustomAnalytics":true,"allowAccountingLink":true,"digitalProducts":true,"sitemapElement":false},"mobileBar":{"enabled":false,"theme":"accent","email":{"active":true},"location":{"active":true},"phone":{"active":true},"whatsapp":{"active":false},"social":{"active":false,"network":"facebook"}},"webshop":{"enabled":true,"currency":"USD","taxEnabled":false,"taxInclusive":false,"vatDisclaimerVisible":false,"orderNotice":null,"orderConfirmation":null,"freeShipping":true,"freeShippingAmount":"0.00","shippingDisclaimerVisible":false,"pickupAllowed":false,"couponAllowed":false,"detailsPageAvailable":true,"socialMediaVisible":true,"termsPage":null,"termsPageUrl":null,"extraTerms":null,"pricingVisible":true,"orderButtonVisible":true,"checkoutRestricted":false,"shippingAdvanced":false,"shippingAdvancedBackEnd":false,"soldOutVisible":true,"backInStockNotificationEnabled":true,"canAddProducts":true,"nextOrderNumber":6,"allowedServicePoints":[],"sendcloudConfigured":false,"sendcloudFallbackPublicKey":"a3d50033a59b4a598f1d7ce7e72aafdf","taxExemptionAllowed":false,"invoiceComment":null,"emptyCartVisible":true,"minimumOrderPrice":null,"productNumbersEnabled":false,"wishlistEnabled":true,"hideTaxOnCart":true},"isTreatedAsWebshop":true};                            window.JOUWWEB.cart = {"products":[],"coupon":null,"shippingCountryCode":null,"shippingChoice":null,"breakdown":[]};                            window.JOUWWEB.scripts = ["website-rendering\/webshop"];                        window.parent.JOUWWEB.colorPalette = window.JOUWWEB.colorPalette;
        </script>
                    <meta name="robots" content="noindex,nofollow">
                <title>Page not found</title>
                                            <link href="https://primary.jwwb.nl/public/s/d/n/temp-wkqkzshgrmmennlcbgpe/touch-icon-iphone.png?bust=1782637990" rel="apple-touch-icon" sizes="60x60">                                                <link href="https://primary.jwwb.nl/public/s/d/n/temp-wkqkzshgrmmennlcbgpe/touch-icon-ipad.png?bust=1782637990" rel="apple-touch-icon" sizes="76x76">                                                <link href="https://primary.jwwb.nl/public/s/d/n/temp-wkqkzshgrmmennlcbgpe/touch-icon-iphone-retina.png?bust=1782637990" rel="apple-touch-icon" sizes="120x120">                                                <link href="https://primary.jwwb.nl/public/s/d/n/temp-wkqkzshgrmmennlcbgpe/touch-icon-ipad-retina.png?bust=1782637990" rel="apple-touch-icon" sizes="152x152">                                                <link href="https://primary.jwwb.nl/public/s/d/n/temp-wkqkzshgrmmennlcbgpe/favicon.png?bust=1782637990" rel="shortcut icon">                                                <link href="https://primary.jwwb.nl/public/s/d/n/temp-wkqkzshgrmmennlcbgpe/favicon.png?bust=1782637990" rel="icon">                                                        <meta name="twitter:card" content="summary">
                                                    <meta name="google-site-verification" content="Ocyray4rGeIaavLucp7oN9fHAvevB-L_bYfk4Q63acg" />                            <script src="https://plausible.io/js/script.manual.js" nonce="b834adb9fe316030b0d54ffa4d90b2d7" data-turbo-track="reload" defer data-domain="shard7.jouwweb.nl"></script>
<link rel="stylesheet" type="text/css" href="https://gfonts.jwwb.nl/css?display=fallback&amp;family=Lato%3A400%2C700%2C400italic%2C700italic%7CLora%3A400%2C700%2C400italic%2C700italic" nonce="b834adb9fe316030b0d54ffa4d90b2d7" data-turbo-track="dynamic">
<script src="https://assets.jwwb.nl/assets/website-rendering-i18n/en-AU.js?bust=08ed5d835ea1c6936afa" nonce="b834adb9fe316030b0d54ffa4d90b2d7" data-turbo-track="reload" defer></script>
<script src="https://assets.jwwb.nl/assets/website-rendering/runtime.a2455a67aab510c8778e.js?bust=2b1f8035561513566faf" nonce="b834adb9fe316030b0d54ffa4d90b2d7" data-turbo-track="reload" defer></script>
<script src="https://assets.jwwb.nl/assets/website-rendering/964.a958855da07340f5fab3.js?bust=7f40a67c5d0bee8ef59b" nonce="b834adb9fe316030b0d54ffa4d90b2d7" data-turbo-track="reload" defer></script>
<script src="https://assets.jwwb.nl/assets/website-rendering/main.e74ad4a668f6c530cbb3.js?bust=45c04c3093ba4798670d" nonce="b834adb9fe316030b0d54ffa4d90b2d7" data-turbo-track="reload" defer></script>
<link rel="preload" href="https://assets.jwwb.nl/assets/website-rendering/main.b3be791fe0ea9410a7ef.css?bust=bebe292eacb5115a15cc" as="style">
<link rel="preload" href="https://assets.jwwb.nl/assets/website-rendering/fonts/icons-website-rendering/font/website-rendering.woff2?bust=eeda4129169be2e46f13" as="font" crossorigin>
<link rel="preconnect" href="https://gfonts.jwwb.nl">
<link rel="preconnect" href="https://assets.jwwb.nl">
<link rel="stylesheet" type="text/css" href="https://assets.jwwb.nl/assets/website-rendering/main.b3be791fe0ea9410a7ef.css?bust=bebe292eacb5115a15cc" nonce="b834adb9fe316030b0d54ffa4d90b2d7" data-turbo-track="dynamic">
<link rel="stylesheet" type="text/css" href="https://primary.jwwb.nl/public/s/d/n/temp-wkqkzshgrmmennlcbgpe/style.css?bust=1790984036" nonce="b834adb9fe316030b0d54ffa4d90b2d7" data-turbo-track="dynamic" id="jw-website-stylesheet">    </head>
    <body
        id="top"
        class="jw-is-no-slideshow jw-header-is-image jw-is-segment-custom jw-is-frontend jw-is-no-sidebar jw-is-no-messagebar jw-is-no-touch-device jw-is-no-mobile"
                                                                            data-jouwweb-segment-type="custom"
                                                data-template-threshold="960"
                                                data-template-name="concert-banner&#x7C;dark"
                            itemscope
        itemtype="https://schema.org/WebPage"
    >
                                    <meta itemprop="url" content="https://www.heartavenueassociation.com/www.webador.pl">
        <a href="/www.webador.pl#main-content" class="jw-skip-link">
            Skip to main content        </a>
        <div class="jw-background"></div>
        <div class="jw-body">
            <div class="jw-mobile-menu jw-mobile-is-logo js-mobile-menu">
            <button
            type="button"
            class="jw-mobile-menu__button jw-mobile-toggle"
            aria-label="Toggle menu"
        >
            <span class="jw-icon-burger"></span>
        </button>
        <div class="jw-mobile-header jw-mobile-header--image">
        <a            class="jw-mobile-header-content"
                            href="/"
                        >
                            <img class="jw-mobile-logo jw-mobile-logo--square" src="https://primary.jwwb.nl/public/s/d/n/temp-wkqkzshgrmmennlcbgpe/image-removebg-preview-3-high.png?enable-io=true&amp;enable=upscale&amp;height=70" srcset="https://primary.jwwb.nl/public/s/d/n/temp-wkqkzshgrmmennlcbgpe/image-removebg-preview-3-high.png?enable-io=true&amp;enable=upscale&amp;height=70 1x, https://primary.jwwb.nl/public/s/d/n/temp-wkqkzshgrmmennlcbgpe/image-removebg-preview-3-high.png?enable-io=true&amp;enable=upscale&amp;height=140&amp;quality=70 2x" alt="Heart Avenue Association" title="Heart Avenue Association">                                </a>
    </div>

        <a
        href="/cart"
        class="jw-mobile-menu__button jw-mobile-header-cart"
        aria-label="View cart"
    >
        <span class="jw-icon-badge-wrapper">
            <span class="website-rendering-icon-basket" aria-hidden="true"></span>
            <span class="jw-icon-badge hidden" aria-hidden="true"></span>
        </span>
    </a>
    
    </div>
    <div class="jw-mobile-menu-search jw-mobile-menu-search--hidden">
        <form
            action="/search"
            method="get"
            class="jw-mobile-menu-search__box"
        >
            <input
                type="text"
                name="q"
                value=""
                placeholder="Search..."
                class="jw-mobile-menu-search__input"
                aria-label="Search"
            >
            <button type="submit" class="jw-btn jw-btn--style-flat jw-mobile-menu-search__button" aria-label="Search">
                <span class="website-rendering-icon-search" aria-hidden="true"></span>
            </button>
            <button type="button" class="jw-btn jw-btn--style-flat jw-mobile-menu-search__button js-cancel-search" aria-label="Cancel search">
                <span class="website-rendering-icon-cancel" aria-hidden="true"></span>
            </button>
        </form>
    </div>
<header class="header-wrap js-topbar-content-container js-fixed-header-container">
        <div class="header-wrap__inner">
        <div class="header">
            <div class="jw-header-logo">
            <div
    id="jw-header-image-container"
    class="jw-header jw-header-image-container jw-header-image-toggle"
>
            <a href="/">
        <img id="jw-header-image" data-image-id="233396446" srcset="https://primary.jwwb.nl/public/s/d/n/temp-wkqkzshgrmmennlcbgpe/image-removebg-preview-3-high.png?enable-io=true&amp;width=79 79w, https://primary.jwwb.nl/public/s/d/n/temp-wkqkzshgrmmennlcbgpe/image-removebg-preview-3-high.png?enable-io=true&amp;width=158 158w" class="jw-header-image" title="Heart Avenue Association" style="width: 79px;" sizes="79px" width="79" height="79" alt="Heart Avenue Association">                </a>
    </div>
        <div
    class="jw-header jw-header-title-container jw-header-text jw-header-text-toggle"
    data-stylable="true"
>
    <a        id="jw-header-title"
        class="jw-header-title"
                    href="/"
            >
        <span style="color: #cdaeae;">Heart</span> Avenue Association    </a>
</div>
</div>
        </div>
        <nav class="menu jw-menu-copy">
            <ul
    id="jw-menu"
    class="jw-menu jw-menu-horizontal"
    >
            <li
    class="jw-menu-item jw-menu-has-submenu"
>
        <a        class="jw-menu-link"
        href="/"                                    data-page-link-id="36819356"
                            >
                <span class="">
            Home        </span>
                    <span class="jw-arrow jw-arrow-toplevel"></span>
            </a>
                    <ul class="jw-submenu">
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/the-suite"                                    data-page-link-id="36826356"
                            >
                <span class="">
            The Suite        </span>
            </a>
                </li>
                    </ul>
        </li>
            <li
    class="jw-menu-item jw-menu-has-submenu"
>
        <a        class="jw-menu-link"
        href="/volunteer"                                    data-page-link-id="36819448"
                            >
                <span class="">
            Volunteer        </span>
                    <span class="jw-arrow jw-arrow-toplevel"></span>
            </a>
                    <ul class="jw-submenu">
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="https://www.heartavenueassociation.com/volunteer"                                            data-link-id="36859426"
                    >
                <span class="">
            About Volunteering        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/volunteer/remote-volunteer"                                    data-page-link-id="36859038"
                            >
                <span class="">
            Remote volunteer        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/volunteer/volunteer-in-peru"                                    data-page-link-id="36859139"
                            >
                <span class="">
            Volunteer in Peru        </span>
            </a>
                </li>
                    </ul>
        </li>
            <li
    class="jw-menu-item jw-menu-has-submenu"
>
        <a        class="jw-menu-link"
        href="/journalism"                                    data-page-link-id="36819451"
                            >
                <span class="">
            Journalism        </span>
                    <span class="jw-arrow jw-arrow-toplevel"></span>
            </a>
                    <ul class="jw-submenu">
                            <li
    class="jw-menu-item jw-menu-has-submenu"
>
        <a        class="jw-menu-link"
        href="https://www.heartavenueassociation.com/blog-journalism"                                            data-link-id="36824940"
                    >
                <span class="">
            Explore The Press Office        </span>
                    <span class="jw-arrow"></span>
            </a>
                    <ul class="jw-submenu">
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/society-and-current-affairs"                                    data-page-link-id="36824670"
                            >
                <span class="">
            Society and Current Affairs        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/arts-humanities-departament"                                    data-page-link-id="36824604"
                            >
                <span class="">
            Arts &amp; Humanities Departament        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/essays-departament-of-sociology"                                    data-page-link-id="36824642"
                            >
                <span class="">
            Essays - Departament of Sociology        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/department-of-science-and-innovation"                                    data-page-link-id="36824656"
                            >
                <span class="">
            Department of Science and Innovation        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/department-of-pedagogy-and-education"                                    data-page-link-id="36824661"
                            >
                <span class="">
            Department of Pedagogy and Education        </span>
            </a>
                </li>
                    </ul>
        </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/journalism/latest-news-programs"                                    data-page-link-id="36866032"
                            >
                <span class="">
            Latest news | Programs        </span>
            </a>
                </li>
                    </ul>
        </li>
            <li
    class="jw-menu-item jw-menu-has-submenu"
>
        <a        class="jw-menu-link"
        href="/about-us"                                    data-page-link-id="36819449"
                            >
                <span class="">
            About Us        </span>
                    <span class="jw-arrow jw-arrow-toplevel"></span>
            </a>
                    <ul class="jw-submenu">
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="https://www.heartavenueassociation.com/our-work-impact"                                            data-link-id="36841598"
                    >
                <span class="">
            What we do        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/about-us/work-reports"                                    data-page-link-id="36823873"
                            >
                <span class="">
            Work Reports        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/about-us/our-history-team"                                    data-page-link-id="36835224"
                            >
                <span class="">
            Our History &amp; Team        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/about-us/partnerships"                                    data-page-link-id="36851366"
                            >
                <span class="">
            Partnerships        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="https://www.heartavenueassociation.com/about-us-our-work/donate"                                            data-link-id="36859457"
                    >
                <span class="">
            Donate        </span>
            </a>
                </li>
                    </ul>
        </li>
            <li
    class="jw-menu-item jw-menu-has-submenu"
>
        <a        class="jw-menu-link"
        href="/digital-library"                                    data-page-link-id="36826565"
                            >
                <span class="">
            Digital Library        </span>
                    <span class="jw-arrow jw-arrow-toplevel"></span>
            </a>
                    <ul class="jw-submenu">
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="https://www.heartavenueassociation.com/digital-library"                                            data-link-id="36919010"
                    >
                <span class="">
            Reading Room        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/digital-library/storybooks"                                    data-page-link-id="36918770"
                            >
                <span class="">
            StoryBooks        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/digital-library/academic-library"                                    data-page-link-id="36918804"
                            >
                <span class="">
            Academic Library        </span>
            </a>
                </li>
                    </ul>
        </li>
            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/aedralys"                                    data-page-link-id="38546857"
                            >
                <span class="">
            aedralys        </span>
            </a>
                </li>
            <li
    class="jw-menu-item jw-menu-search-item"
>
        <button        class="jw-menu-link jw-menu-link--icon jw-text-button"
                                                            title="Search"
            >
                                <span class="website-rendering-icon-search"></span>
                            <span class="hidden-desktop-horizontal-menu">
            Search        </span>
            </button>
                
            <div class="jw-popover-container jw-popover-container--inline is-hidden">
                <div class="jw-popover-backdrop"></div>
                <div class="jw-popover">
                    <div class="jw-popover__arrow"></div>
                    <div class="jw-popover__content">
                        <form  class="jw-search" action="/search" method="get">
                            
                            <input class="jw-search__input" type="text" name="q" value="" placeholder="Search..." aria-label="Search" >
                            <button class="jw-search__submit" type="submit" aria-label="Search">
                                <span class="website-rendering-icon-search" aria-hidden="true"></span>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
                        </li>
            <li
    class="jw-menu-item jw-menu-wishlist-item js-menu-wishlist-item jw-menu-wishlist-item--hidden"
>
        <a        class="jw-menu-link jw-menu-link--icon"
        href="/wishlist"                                                    title="Wishlist"
            >
                                    <span class="jw-icon-badge-wrapper">
                        <span class="website-rendering-icon-heart"></span>
                                            <span class="jw-icon-badge hidden">
                    0                </span>
                            <span class="hidden-desktop-horizontal-menu">
            Wishlist        </span>
            </a>
                </li>
            <li
    class="jw-menu-item js-menu-cart-item "
>
        <a        class="jw-menu-link jw-menu-link--icon"
        href="/cart"                                                    title="Cart"
            >
                                    <span class="jw-icon-badge-wrapper">
                        <span class="website-rendering-icon-basket"></span>
                                            <span class="jw-icon-badge hidden">
                    0                </span>
                            <span class="hidden-desktop-horizontal-menu">
            Cart        </span>
            </a>
                </li>
        <div
    class="jw-menu-item jw-menu-cta"
    >
    <a
       title="Donate"
       class="jw-btn jw-btn--size-override jw-btn--style-border"
                  href="&#x2F;about-us-our-work&#x2F;donate"
                  >
        <span class="jw-btn-caption">
            Donate        </span>
    </a>
</div>
</ul>
    <script nonce="b834adb9fe316030b0d54ffa4d90b2d7" id="jw-mobile-menu-template" type="text/template">
        <ul id="jw-menu" class="jw-menu jw-menu-horizontal">
                            <li
    class="jw-menu-item jw-menu-search-item"
>
                
                 <li class="jw-menu-item jw-mobile-menu-search-item">
                    <form class="jw-search" action="/search" method="get">
                        <input class="jw-search__input" type="text" name="q" value="" placeholder="Search..." aria-label="Search">
                        <button class="jw-search__submit" type="submit" aria-label="Search">
                            <span class="website-rendering-icon-search" aria-hidden="true"></span>
                        </button>
                    </form>
                </li>
                        </li>
                            <li
    class="jw-menu-item jw-menu-has-submenu"
>
        <a        class="jw-menu-link"
        href="/"                                    data-page-link-id="36819356"
                            >
                <span class="">
            Home        </span>
                    <span class="jw-arrow jw-arrow-toplevel"></span>
            </a>
                    <ul class="jw-submenu">
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/the-suite"                                    data-page-link-id="36826356"
                            >
                <span class="">
            The Suite        </span>
            </a>
                </li>
                    </ul>
        </li>
                            <li
    class="jw-menu-item jw-menu-has-submenu"
>
        <a        class="jw-menu-link"
        href="/volunteer"                                    data-page-link-id="36819448"
                            >
                <span class="">
            Volunteer        </span>
                    <span class="jw-arrow jw-arrow-toplevel"></span>
            </a>
                    <ul class="jw-submenu">
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="https://www.heartavenueassociation.com/volunteer"                                            data-link-id="36859426"
                    >
                <span class="">
            About Volunteering        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/volunteer/remote-volunteer"                                    data-page-link-id="36859038"
                            >
                <span class="">
            Remote volunteer        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/volunteer/volunteer-in-peru"                                    data-page-link-id="36859139"
                            >
                <span class="">
            Volunteer in Peru        </span>
            </a>
                </li>
                    </ul>
        </li>
                            <li
    class="jw-menu-item jw-menu-has-submenu"
>
        <a        class="jw-menu-link"
        href="/journalism"                                    data-page-link-id="36819451"
                            >
                <span class="">
            Journalism        </span>
                    <span class="jw-arrow jw-arrow-toplevel"></span>
            </a>
                    <ul class="jw-submenu">
                            <li
    class="jw-menu-item jw-menu-has-submenu"
>
        <a        class="jw-menu-link"
        href="https://www.heartavenueassociation.com/blog-journalism"                                            data-link-id="36824940"
                    >
                <span class="">
            Explore The Press Office        </span>
                    <span class="jw-arrow"></span>
            </a>
                    <ul class="jw-submenu">
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/society-and-current-affairs"                                    data-page-link-id="36824670"
                            >
                <span class="">
            Society and Current Affairs        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/arts-humanities-departament"                                    data-page-link-id="36824604"
                            >
                <span class="">
            Arts &amp; Humanities Departament        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/essays-departament-of-sociology"                                    data-page-link-id="36824642"
                            >
                <span class="">
            Essays - Departament of Sociology        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/department-of-science-and-innovation"                                    data-page-link-id="36824656"
                            >
                <span class="">
            Department of Science and Innovation        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/department-of-pedagogy-and-education"                                    data-page-link-id="36824661"
                            >
                <span class="">
            Department of Pedagogy and Education        </span>
            </a>
                </li>
                    </ul>
        </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/journalism/latest-news-programs"                                    data-page-link-id="36866032"
                            >
                <span class="">
            Latest news | Programs        </span>
            </a>
                </li>
                    </ul>
        </li>
                            <li
    class="jw-menu-item jw-menu-has-submenu"
>
        <a        class="jw-menu-link"
        href="/about-us"                                    data-page-link-id="36819449"
                            >
                <span class="">
            About Us        </span>
                    <span class="jw-arrow jw-arrow-toplevel"></span>
            </a>
                    <ul class="jw-submenu">
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="https://www.heartavenueassociation.com/our-work-impact"                                            data-link-id="36841598"
                    >
                <span class="">
            What we do        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/about-us/work-reports"                                    data-page-link-id="36823873"
                            >
                <span class="">
            Work Reports        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/about-us/our-history-team"                                    data-page-link-id="36835224"
                            >
                <span class="">
            Our History &amp; Team        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/about-us/partnerships"                                    data-page-link-id="36851366"
                            >
                <span class="">
            Partnerships        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="https://www.heartavenueassociation.com/about-us-our-work/donate"                                            data-link-id="36859457"
                    >
                <span class="">
            Donate        </span>
            </a>
                </li>
                    </ul>
        </li>
                            <li
    class="jw-menu-item jw-menu-has-submenu"
>
        <a        class="jw-menu-link"
        href="/digital-library"                                    data-page-link-id="36826565"
                            >
                <span class="">
            Digital Library        </span>
                    <span class="jw-arrow jw-arrow-toplevel"></span>
            </a>
                    <ul class="jw-submenu">
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="https://www.heartavenueassociation.com/digital-library"                                            data-link-id="36919010"
                    >
                <span class="">
            Reading Room        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/digital-library/storybooks"                                    data-page-link-id="36918770"
                            >
                <span class="">
            StoryBooks        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/digital-library/academic-library"                                    data-page-link-id="36918804"
                            >
                <span class="">
            Academic Library        </span>
            </a>
                </li>
                    </ul>
        </li>
                            <li
    class="jw-menu-item"
>
        <a        class="jw-menu-link"
        href="/aedralys"                                    data-page-link-id="38546857"
                            >
                <span class="">
            aedralys        </span>
            </a>
                </li>
                            <li
    class="jw-menu-item jw-menu-wishlist-item js-menu-wishlist-item jw-menu-wishlist-item--hidden"
>
        <a        class="jw-menu-link jw-menu-link--icon"
        href="/wishlist"                                            >
                                    <span class="jw-icon-badge-wrapper">
                        <span class="website-rendering-icon-heart"></span>
                                            <span class="jw-icon-badge hidden">
                    0                </span>
                            <span class="">
            Wishlist        </span>
            </a>
                </li>
                        <div
    class="jw-menu-item jw-menu-cta"
    >
    <a
       title="Donate"
       class="jw-btn jw-btn--size-override jw-btn--style-border"
                  href="&#x2F;about-us-our-work&#x2F;donate"
                  >
        <span class="jw-btn-caption">
            Donate        </span>
    </a>
</div>
        </ul>
    </script>
        </nav>
    </div>
</header>
<script nonce="b834adb9fe316030b0d54ffa4d90b2d7">
    JOUWWEB.templateConfig = {
        header: {
            selector: '.header-wrap__inner',
            mobileSelector: '.jw-mobile-menu',
            updatePusher: function (topHeight) {
                var $sliderStyle = $('#sliderStyle');

                if ($sliderStyle.length === 0) {
                    $sliderStyle = $('<style />')
                        .attr('id', 'sliderStyle')
                        .appendTo(document.body);
                }

                // Header height without mobile bar
                var headerHeight = $('.header-wrap__inner').outerHeight();

                var paddingTop = topHeight;
                var paddingBottom = Math.min(headerHeight * (2/3), 60);
                $sliderStyle.html(
                    '.jw-slideshow-slide-content {' +
                    '    padding-top: ' + paddingTop + 'px;' +
                    '    padding-bottom: ' + paddingBottom + 'px;' +
                    '}' +
                    '.bx-controls-direction {' +
                    '    margin-top: ' + ((paddingTop - paddingBottom) / 2) + 'px;' +
                    '}'
                );

                // make sure slider also gets correct height (because of the added padding)
                $('.jw-slideshow-slide[aria-hidden=false]').each(function (index) {
                    var $this = $(this);
                    topHeight = $this.outerHeight() > topHeight ? $this.outerHeight() : topHeight;
                    $this.closest('.bx-viewport').css({
                        height: topHeight + 'px',
                    });
                });

                // If a page has a message-bar, offset the mobile nav.
                const $messageBar = $('.message-bar');
                if ($messageBar.length > 0) {
                    $('.js-mobile-menu, .jw-menu-clone').css('top', $messageBar.outerHeight());
                }
            },
        },
        mainContentOffset: function () {
            const $body = $('body');

            function measureAffixedHeaderHeight() {
                const $headerWrap = $('.header-wrap');
                const $headerWrapInner = $('.header-wrap__inner');

                // Early return if header is already affixed
                if ($body.hasClass('jw-is-header-affix')) {
                    return $headerWrap.height();
                }

                // Switch to affixed header (without transition)
                $headerWrapInner.css('transition', 'none');
                $body.addClass('jw-is-header-affix');

                // Measure affixed header height
                const headerHeight = $headerWrap.height();

                // Switch back to unaffixed header (without transition)
                $body.removeClass('jw-is-header-affix');
                $headerWrap.height(); // force reflow
                $headerWrapInner.css('transition', '');

                return headerHeight;
            }

            const headerHeight = measureAffixedHeaderHeight();
            return $('.main-content').offset().top - ($body.hasClass('jw-menu-is-mobile') ? 0 : headerHeight);
        },
    };
</script>
<div class="main-content">
    
<main id="main-content" class="block-content">
    <div data-section-name="content" class="jw-section jw-section-content jw-responsive">
        <div class="jw-strip jw-strip--default jw-strip--style-color jw-strip--primary jw-strip--color-default jw-strip--padding-both jw-strip--vertical-padding-default jw-strip--border-shape-none"><div class="jw-strip__background-container"><div class="jw-strip__background"></div></div><div class="jw-strip__content-container"><div class="jw-strip__content jw-responsive">
                    <h1>Page not found</h1>
<p>
    Sorry, we couldn't find this page. It may no longer exist.</p>

</div></div></div>            </div>
</main>
    </div>
<footer class="block-footer">
    <div
        data-section-name="footer"
        class="jw-section jw-section-footer jw-responsive"
    >
                <div class="jw-strip jw-strip--default jw-strip--style-none jw-strip--primary jw-strip--padding-both jw-strip--vertical-padding-default jw-strip--border-shape-none"><div class="jw-strip__content-container"><div class="jw-strip__content jw-responsive">            <div class="jw-block-element"><div
    id="jw-element-741071018"
    data-jw-element-id="741071018"
        class="jw-tree-node jw-element jw-simple-root jw-tree-container jw-responsive jw-node-is-first-child jw-node-is-last-child"
>
    <div
    id="jw-element-760385851"
    data-jw-element-id="760385851"
        class="jw-tree-node jw-element jw-html jw-node-is-first-child"
>
    <div class="jw-html-wrapper">
    <!-- Reproductor flotante interactivo de lista de canciones (Pop-up) -->
<div id="ha-music-widget" style="position: fixed; bottom: 25px; left: 25px; z-index: 99999; cursor: pointer; display: flex; align-items: center; justify-content: center; width: 55px; height: 55px; background: rgba(255, 220, 240, 0.75); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); border: 1.5px solid rgba(255, 255, 255, 0.9); border-radius: 50%; box-shadow: 0 8px 25px rgba(245, 56, 164, 0.35); transition: transform 0.3s ease;">
    <!-- SVG de Corazón con Nota Musical -->
    <svg viewbox="0 0 24 24" style="width: 28px; height: 28px; fill: #FF0091; filter: drop-shadow(0 2px 4px rgba(255,255,255,0.8));">
        <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"></path>
    </svg>
    <span style="position: absolute; font-size: 11px; font-weight: bold; color: #ffffff; text-shadow: 0 1px 3px rgba(245,56,164,0.9); pointer-events: none;">♫</span>
</div>

<!-- Pop-up Selector de Canciones / Panel de Control -->
<div id="ha-music-popup" style="position: fixed; bottom: 95px; left: 25px; z-index: 99998; width: 340px; background: rgba(20, 10, 20, 0.85); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); border: 1.5px solid rgba(255, 158, 205, 0.4); border-radius: 20px; box-shadow: 0 12px 35px rgba(0, 0, 0, 0.6); padding: 22px; display: none; flex-direction: column; gap: 14px; font-family: 'Montserrat', sans-serif; box-sizing: border-box;">
    
    <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255, 158, 205, 0.2); padding-bottom: 10px;">
        <span id="ha-popup-title" style="font-family: 'Cinzel', serif; font-size: 14px; font-weight: 700; color: #ffffff; letter-spacing: 1px;">Magic Playlist</span>
        
        <!-- Interruptor (Toggle Switch) -->
        <div style="display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 10px; color: rgba(255,255,255,0.7); text-transform: uppercase; letter-spacing: 0.5px;">Music</span>
            <label class="ha-switch">
                <input type="checkbox" id="ha-toggle-power-checkbox">
                <span class="ha-slider ha-round"></span>
            </label>
        </div>
    </div>

    <!-- Lista de Canciones -->
    <div id="ha-playlist-container" style="display: flex; flex-direction: column; gap: 8px; max-height: 290px; overflow-y: auto; padding-right: 6px;">
        <!-- Los elementos se generan con JS -->
    </div>
</div>

<style>
    @keyframes heartBeatSoft {
        0% { transform: scale(1); box-shadow: 0 8px 25px rgba(245, 56, 164, 0.35); }
        50% { transform: scale(1.08); box-shadow: 0 12px 30px rgba(245, 56, 164, 0.5); }
        100% { transform: scale(1); box-shadow: 0 8px 25px rgba(245, 56, 164, 0.35); }
    }
    .ha-pulsing { animation: heartBeatSoft 2s infinite ease-in-out; }
    .ha-paused { animation: none !important; opacity: 0.6; filter: grayscale(30%); }

    /* Estilo del scrollbar del pop-up */
    #ha-playlist-container::-webkit-scrollbar { width: 5px; }
    #ha-playlist-container::-webkit-scrollbar-thumb { background: rgba(255, 158, 205, 0.4); border-radius: 4px; }

    .ha-song-item {
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        padding: 10px 14px;
        border-radius: 10px;
        color: #ddd;
        font-size: 12.5px;
        line-height: 1.3;
        cursor: pointer;
        transition: all 0.2s ease;
        text-align: left;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .ha-song-item:hover {
        background: rgba(255, 158, 205, 0.25);
        color: #fff;
        border-color: rgba(255, 158, 205, 0.5);
    }
    .ha-song-item.active-song {
        background: rgba(255, 158, 205, 0.4);
        border-color: #ffb6c1;
        color: #fff;
        font-weight: 600;
        box-shadow: 0 0 10px rgba(255, 158, 205, 0.3);
    }

    /* ESTILOS DEL INTERRUPTOR CON BOLITA BRILLANTE */
    .ha-switch {
        position: relative;
        display: inline-block;
        width: 36px;
        height: 18px;
    }
    .ha-switch input { 
        opacity: 0;
        width: 0;
        height: 0;
    }
    .ha-slider {
        position: absolute;
        cursor: pointer;
        top: 0; left: 0; right: 0; bottom: 0;
        background-color: rgba(255, 255, 255, 0.1);
        transition: .4s;
        border: 1px solid rgba(255, 158, 205, 0.3);
    }
    .ha-slider:before {
        position: absolute;
        content: "";
        height: 12px;
        width: 12px;
        left: 2px;
        bottom: 2px;
        background-color: #fff;
        transition: .4s;
        box-shadow: 0 0 4px rgba(255, 255, 255, 0.5);
    }
    input:checked + .ha-slider {
        background-color: rgba(255, 0, 145, 0.4);
        border-color: #FF0091;
    }
    input:checked + .ha-slider:before {
        transform: translateX(18px);
        background-color: #ffffff;
        box-shadow: 0 0 8px #ffffff, 0 0 15px #FF0091;
    }
    .ha-slider.ha-round {
        border-radius: 20px;
    }
    .ha-slider.ha-round:before {
        border-radius: 50%;
    }
</style>

<!-- Audio Element con la lista completa -->
<audio id="ha-bg-audio" preload="auto"></audio>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const audio = document.getElementById("ha-bg-audio");
        const widget = document.getElementById("ha-music-widget");
        const popup = document.getElementById("ha-music-popup");
        const toggleCheckbox = document.getElementById("ha-toggle-power-checkbox");
        const playlistContainer = document.getElementById("ha-playlist-container");
        const popupTitle = document.getElementById("ha-popup-title");

        // VALIDACIÓN DE LA PÁGINA
        const currentUrl = window.location.href;
        const isJournalismPage = currentUrl.includes("/journalism");
        // Nueva validación para la página específica 117
        const isPage117 = currentUrl.endsWith("/117") || currentUrl.includes("/117?");

        // Audio especial para Journaling
        const journalismAudioSrc = "https://www.image2url.com/r2/default/audio/1785811704308-4cc61c3e-d6c9-4709-b75c-7e18fc372735.mp3";

        // Listado oficial de canciones integradas
        const playlist = [
            { title: "Fairy Theme", src: "https://archive.org/download/videoplayback-1_20260803_0732/videoplayback%20%281%29.mp3" },
            { title: "A new kind of love", src: "https://archive.org/download/frou-frou-a-new-kind-of-love/frou%20frou%20-%20A%20New%20Kind%20Of%20Love.mp3" }, // Índice 1
            { title: "Lullaby of the New Moon", src: "https://archive.org/download/lullaby-of-the-new-moon-i-somnias-a-luna/Lullaby%20of%20the%20New%20Moon%20%28I%29%20_%20Somnias%20a%20Luna.mp3" },
            { title: "Dream Aria", src: "https://archive.org/download/08-dream-aria-genshin-impact-main-theme-var.-genshin-impact-1/%2308%20Dream%20Aria%20%28Genshin%20Impact%20Main%20Theme%20Var.%29Genshin%20Impact%20%281%29.mp3" },
            { title: "Cure For Me", src: "https://archive.org/download/aurora-cure-for-me-official-instrumental/Aurora%20-%20Cure%20For%20Me%20%28Official%20Instrumental%29.mp3" },
            { title: "Baila mi corazón", src: "https://archive.org/download/belanova-baila-mi-corazon-2/Belanova%20%20Baila%20Mi%20Coraz%C3%B3n%281%29.mp3" },
            { title: "Supernova Love", src: "https://archive.org/download/ive-david-guetta-supernova-love-official-music-video_202608/IVE%20David%20Guetta%20%20Supernova%20Love%20Official%20Music%20Video.mp3" }
        ];

        audio.volume = 0.6;

        // Lógica de selección de canción inicial
        let currentSongIndex;
        let isMutedUser = localStorage.getItem("ha_audio_muted") === "true";
        
        // --- INICIO EDICIÓN PARA PÁGINA 117 ---
        if (isPage117) {
            // Forzamos la canción "A new kind of love" (Índice 1 de la playlist)
            currentSongIndex = 1;
            // Opcional: Guardamos este índice como el último reproducido
            localStorage.setItem("ha_song_index", currentSongIndex);
        } else {
            // Lógica normal para el resto de páginas
            currentSongIndex = parseInt(localStorage.getItem("ha_song_index")) || 0;
        }
        // --- FIN EDICIÓN PARA PÁGINA 117 ---

        // Sincronizar estado del interruptor
        toggleCheckbox.checked = !isMutedUser;

        if (isJournalismPage) {
            audio.src = journalismAudioSrc;
            playlistContainer.style.display = "none";
            popupTitle.textContent = "Journaling Theme";
            
            let savedTime = parseFloat(localStorage.getItem("ha_audio_time_journal")) || 0;
            audio.currentTime = savedTime;

        } else {
            // Validación de seguridad para el índice
            if (currentSongIndex >= playlist.length || currentSongIndex < 0) {
                currentSongIndex = 0;
            }

            audio.src = playlist[currentSongIndex].src;
            
            // --- EDICIÓN TIEMPO PARA PÁGINA 117 ---
            let savedTime = 0;
            if (!isPage117) {
                // Solo recuperamos el tiempo guardado si NO estamos en la página 117
                savedTime = parseFloat(localStorage.getItem("ha_audio_time")) || 0;
            }
            // Si es la página 117, savedTime se queda en 0 para reproducir desde el inicio
            audio.currentTime = savedTime;

            // Construir elementos de la lista
            playlist.forEach((song, index) => {
                const item = document.createElement("div");
                item.className = "ha-song-item" + (index === currentSongIndex ? " active-song" : "");
                item.textContent = (index + 1) + ". " + song.title;
                item.addEventListener("click", function(e) {
                    e.stopPropagation();
                    changeSong(index);
                });
                playlistContainer.appendChild(item);
            });
        }

        function updateActiveUI() {
            if (isJournalismPage) return;
            const items = playlistContainer.querySelectorAll(".ha-song-item");
            items.forEach((it, idx) => {
                if (idx === currentSongIndex) {
                    it.classList.add("active-song");
                } else {
                    it.classList.remove("active-song");
                }
            });
        }

        function changeSong(index) {
            if (isJournalismPage) return;
            currentSongIndex = index;
            localStorage.setItem("ha_song_index", currentSongIndex);
            audio.src = playlist[currentSongIndex].src;
            audio.currentTime = 0;
            audio.play().then(() => {
                widget.classList.remove("ha-paused");
                widget.classList.add("ha-pulsing");
                localStorage.setItem("ha_audio_muted", "false");
                toggleCheckbox.checked = true;
                updateActiveUI();
            }).catch(err => console.log("Error al cambiar canción:", err));
        }

        // Reproductor automático
        let hasInteracted = false;
        function triggerAutoPlay() {
            if (!hasInteracted && isMutedUser === false) {
                hasInteracted = true;
                audio.play().then(() => {
                    widget.classList.remove("ha-paused");
                    widget.classList.add("ha-pulsing");
                    toggleCheckbox.checked = true;
                }).catch(e => {
                    console.log("Autoplay bloqueado por el navegador");
                    widget.classList.add("ha-paused");
                    toggleCheckbox.checked = false;
                });
            }
        }

        ["click", "scroll", "keydown", "touchstart"].forEach(evt => {
            window.addEventListener(evt, triggerAutoPlay, { once: true });
        });

        // Estado inicial de reproducción
        if (isMutedUser) {
            widget.classList.add("ha-paused");
        } else {
            // Intento de reproducción inmediata (suele fallar sin interacción previa)
            audio.play().then(() => {
                widget.classList.remove("ha-paused");
                widget.classList.add("ha-pulsing");
            }).catch(() => {
                widget.classList.add("ha-paused");
                toggleCheckbox.checked = false;
            });
        }

        // Guardar progreso
        setInterval(() => {
            if (!audio.paused) {
                if (isJournalismPage) {
                    localStorage.setItem("ha_audio_time_journal", audio.currentTime);
                } else {
                    localStorage.setItem("ha_audio_time", audio.currentTime);
                }
            }
        }, 1000);

        // Al terminar una canción
        audio.addEventListener("ended", function() {
            if (isJournalismPage) {
                audio.currentTime = 0;
                audio.play();
            } else {
                currentSongIndex = (currentSongIndex + 1) % playlist.length;
                localStorage.setItem("ha_song_index", currentSongIndex);
                audio.src = playlist[currentSongIndex].src;
                audio.play().then(() => {
                    updateActiveUI();
                });
            }
        });

        // Abrir / Cerrar el pop-up
        widget.addEventListener("click", function(e) {
            e.stopPropagation();
            popup.style.display = (popup.style.display === "flex") ? "none" : "flex";
        });

        // Cerrar si se hace clic fuera
        document.addEventListener("click", function(e) {
            if (popup.style.display === "flex" && !popup.contains(e.target) && !widget.contains(e.target)) {
                popup.style.display = "none";
            }
        });

        // Evento del Interruptor Power
        toggleCheckbox.addEventListener("change", function(e) {
            if (this.checked) {
                audio.play().then(() => {
                    widget.classList.remove("ha-paused");
                    widget.classList.add("ha-pulsing");
                    localStorage.setItem("ha_audio_muted", "false");
                    isMutedUser = false;
                }).catch(err => {
                    console.log("Audio play error:", err);
                    this.checked = false;
                });
            } else {
                audio.pause();
                widget.classList.remove("ha-pulsing");
                widget.classList.add("ha-paused");
                localStorage.setItem("ha_audio_muted", "true");
                isMutedUser = true;
            }
        });
    });
</script>    </div>
</div><div
    id="jw-element-760390783"
    data-jw-element-id="760390783"
        class="jw-tree-node jw-element jw-html"
>
    <div class="jw-html-wrapper">
    <!-- ==========================================
     SONIDO DE CLIC DE BOTÓN EN MENÚ Y HIPERVÍNCULOS
     ========================================== -->

<audio id="ha-button-click-sound" preload="auto">
    <source src="https://archive.org/download/button-click-sound-effect/Button%20Click%20-%20Sound%20Effect.mp3" type="audio/mpeg">
</source></audio>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const sound = document.getElementById("ha-button-click-sound");

        // Escuchar clics en toda la página
        document.addEventListener("click", function(e) {
            // Buscar si el elemento presionado (o su contenedor) es un enlace o botón del menú (<a>)
            const link = e.target.closest("a");
            
            if (!link) return; // Si no es un enlace o botón del menú, no hace nada

            const href = link.getAttribute("href");

            // Ignorar enlaces vacíos, anclas internas (#), javascript, correos o teléfonos
            if (!href || href === "#" || href.startsWith("javascript:") || href.startsWith("mailto:") || href.startsWith("tel:")) {
                return;
            }

            // Reproducir el sonido de clic de botón
            if (sound) {
                sound.currentTime = 0;
                sound.play().catch(err => {
                    console.log("Audio bloqueado inicialmente por el navegador:", err);
                });
            }

            // Si el enlace abre en otra pestaña (_blank), dejamos que navegue normalmente sin retraso
            if (link.target === "_blank") {
                return;
            }

            // Si es un cambio de página normal en la misma pestaña:
            // Frenamos la navegación un instante (400 milisegundos) para que el sonido de clic alcance a sonar antes de cambiar de página.
            if (href) {
                e.preventDefault();
                setTimeout(function() {
                    window.location.href = href;
                }, 400);
            }
        });
    });
</script>    </div>
</div><div
    id="jw-element-760403283"
    data-jw-element-id="760403283"
        class="jw-tree-node jw-element jw-html"
>
    <div class="jw-html-wrapper">
    <style>
  /* Partículas de polvo de hadas mágico al hacer clic */
  .fairy-dust-particle {
    position: fixed;
    pointer-events: none;
    width: 7px;
    height: 7px;
    background: radial-gradient(circle, #ffffff 0%, #ff66b2 60%, rgba(255, 42, 141, 0) 100%);
    border-radius: 50%;
    box-shadow: 0 0 8px #ff2a8d, 0 0 14px #ffb6d9;
    z-index: 999999;
    animation: fairyDustExplosion 0.65s cubic-bezier(0.25, 1, 0.5, 1) forwards;
  }

  @keyframes fairyDustExplosion {
    0% {
      transform: translate(0, 0) scale(1.2);
      opacity: 1;
    }
    100% {
      transform: translate(var(--dx), var(--dy)) scale(0.2);
      opacity: 0;
    }
  }
</style>

<script>
  document.addEventListener('click', function(e) {
    // Detecta si el elemento clickeado es un botón, enlace o elemento interactivo
    const targetElement = e.target.closest('button, a, input[type="button"], input[type="submit"], [role="button"], .royale-action-btn');
    
    // Si no es un botón o enlace, no hace nada (ignora clics en el fondo o scroll)
    if (!targetElement) return;

    const x = e.clientX;
    const y = e.clientY;

    // Cantidad de destellos de polvo de hadas
    const particleCount = 14;
    for (let i = 0; i < particleCount; i++) {
      const particle = document.createElement('div');
      particle.className = 'fairy-dust-particle';
      
      particle.style.left = x + 'px';
      particle.style.top = y + 'px';

      // Dispersión radial aleatoria estilo estela de hada
      const angle = Math.random() * Math.PI * 2;
      const distance = 25 + Math.random() * 60;
      const dx = Math.cos(angle) * distance;
      const dy = Math.sin(angle) * distance;

      particle.style.setProperty('--dx', dx + 'px');
      particle.style.setProperty('--dy', dy + 'px');

      document.body.appendChild(particle);

      // Eliminar el elemento del DOM al terminar la animación
      setTimeout(() => {
        particle.remove();
      }, 650);
    }
  });
</script>    </div>
</div><div
    id="jw-element-760885493"
    data-jw-element-id="760885493"
        class="jw-tree-node jw-element jw-html"
>
    <div class="jw-html-wrapper">
    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "NGO",
  "name": "Heart Avenue Association",
  "alternateName": "Hearth Avenue Association",
  "url": "https://hearthavenueassociation.com",
  "foundingDate": "2025-04",
  "founder": {
    "@type": "Person",
    "name": "Edelweiss Dryadis"
  },
  "description": "International nonprofit organization focused on the protection of children and women, and their development in literacy, health, and arts. Offering volunteer opportunities for high school girls (13+), including in-person options in Peru, remote global options, and the opportunity to start a local House.",
  "areaServed": ["PE", "Global"],
  "targetAudience": {
    "@type": "Audience",
    "audienceType": "High school students, young women, volunteers aged 13 and above"
  },
  "knowsAbout": [
    "Child Protection",
    "Women's Protection",
    "Literacy Development",
    "Health and Community Well-being",
    "Arts and Cultural Diversity",
    "Youth Volunteering"
  ]
}
</script>    </div>
</div><div
    id="jw-element-765582184"
    data-jw-element-id="765582184"
        class="jw-tree-node jw-element jw-image-text jw-node-is-last-child"
>
    <div class="jw-element-imagetext-text">
            <h2 class="">Contact Us &amp; Partnerships</h2>
<p class="custom-cursor-default-hover"><a class="" href="mailto:Heartavenueassociation@gmail.com">Heartavenueassociation@gmail.com</a></p>
<p class="custom-cursor-default-hover"><strong>Adress:</strong><span>&nbsp;</span>1531 SE Royal Green Cir, Port Saint Lucie FL 34952 Florida, USA<br />Certificate No. 00204-2025-MINEDU/DM-SENAJU</p>
<p class="">&copy; 2026 Heart Avenue Association</p>    </div>
</div></div></div>                                        <div class="jw-block-footer-content">
                    <div class="jw-credits clear">
                        <div class="jw-credits-owner">
                            <div id="jw-footer-text">
                                <div class="jw-footer-text-content">
                                                                    </div>
                            </div>
                        </div>
                        <div class="jw-credits-right">
                                                                                </div>
                    </div>
                </div>
                    </div></div></div>    </div>
</footer>
            
<div class="jw-bottom-bar__container">
    </div>
<div class="jw-bottom-bar__spacer">
    </div>

            <div id="jw-variable-loaded" style="display: none;"></div>
            <div id="jw-variable-values" style="display: none;">
                                    <span data-jw-variable-key="background-color" class="jw-variable-value-background-color"></span>
                                    <span data-jw-variable-key="background" class="jw-variable-value-background"></span>
                                    <span data-jw-variable-key="font-family" class="jw-variable-value-font-family"></span>
                                    <span data-jw-variable-key="paragraph-color" class="jw-variable-value-paragraph-color"></span>
                                    <span data-jw-variable-key="paragraph-link-color" class="jw-variable-value-paragraph-link-color"></span>
                                    <span data-jw-variable-key="paragraph-font-size" class="jw-variable-value-paragraph-font-size"></span>
                                    <span data-jw-variable-key="heading-color" class="jw-variable-value-heading-color"></span>
                                    <span data-jw-variable-key="heading-link-color" class="jw-variable-value-heading-link-color"></span>
                                    <span data-jw-variable-key="heading-font-size" class="jw-variable-value-heading-font-size"></span>
                                    <span data-jw-variable-key="heading-font-family" class="jw-variable-value-heading-font-family"></span>
                                    <span data-jw-variable-key="menu-text-color" class="jw-variable-value-menu-text-color"></span>
                                    <span data-jw-variable-key="menu-text-link-color" class="jw-variable-value-menu-text-link-color"></span>
                                    <span data-jw-variable-key="menu-text-font-size" class="jw-variable-value-menu-text-font-size"></span>
                                    <span data-jw-variable-key="menu-font-family" class="jw-variable-value-menu-font-family"></span>
                                    <span data-jw-variable-key="menu-capitalize" class="jw-variable-value-menu-capitalize"></span>
                                    <span data-jw-variable-key="website-size" class="jw-variable-value-website-size"></span>
                                    <span data-jw-variable-key="footer-text-color" class="jw-variable-value-footer-text-color"></span>
                                    <span data-jw-variable-key="footer-text-link-color" class="jw-variable-value-footer-text-link-color"></span>
                                    <span data-jw-variable-key="footer-text-font-size" class="jw-variable-value-footer-text-font-size"></span>
                                    <span data-jw-variable-key="content-color" class="jw-variable-value-content-color"></span>
                                    <span data-jw-variable-key="header-color" class="jw-variable-value-header-color"></span>
                                    <span data-jw-variable-key="accent-color" class="jw-variable-value-accent-color"></span>
                                    <span data-jw-variable-key="footer-color" class="jw-variable-value-footer-color"></span>
                                    <span data-jw-variable-key="menu-text-over-banner-color" class="jw-variable-value-menu-text-over-banner-color"></span>
                            </div>
        </div>
                            <script nonce="b834adb9fe316030b0d54ffa4d90b2d7" type="application/ld+json">[{"@context":"https:\/\/schema.org","@type":"Organization","url":"https:\/\/www.heartavenueassociation.com\/","name":"Heart Avenue Association","logo":{"@type":"ImageObject","url":"https:\/\/primary.jwwb.nl\/public\/s\/d\/n\/temp-wkqkzshgrmmennlcbgpe\/image-removebg-preview-3-high.png?enable-io=true&enable=upscale&height=60","width":60,"height":60}}]</script>
                <script nonce="b834adb9fe316030b0d54ffa4d90b2d7">window.JOUWWEB = window.JOUWWEB || {}; window.JOUWWEB.experiment = {"enrollments":{},"defaults":{"only-annual-discount-restart":"3months-50pct","emphasize-strips-in-sidebar":"on","general-template-replacement":"on","ai-new-subpage-flow":"balanced","page-fill-explainer":"on","onboarding-banner-generation":"on","drip-mail-timings":"on","direct-debit-payment-notice-urgency":"on","cycle-selector-layout":"listed","logo-gemini-25-successor":"gemini-31-flash-lite-image","landing-overall-improvements":"on"}};</script>        <script nonce="b834adb9fe316030b0d54ffa4d90b2d7">
            window.JOUWWEB = window.JOUWWEB || {};
            window.JOUWWEB.cookieConsent = {"theme":"jw","showLink":false,"content":{"message":"This website uses cookies to enhance your experience and display tailored ads. By clicking \"Accept\", you consent to the use of all the cookies.","allow":"Accept","deny":"Decline"},"type":"opt-in","autoOpen":true,"cookie":{"name":"cookieconsent_status"}};
        </script>
<script nonce="b834adb9fe316030b0d54ffa4d90b2d7">window.plausible = window.plausible || function() { (window.plausible.q = window.plausible.q || []).push(arguments) };plausible('pageview', { props: {website: 8366932 }});</script>                    <!-- Forzar modo claro y bloquear inversiÃ³n automÃ¡tica de colores en celulares -->


   
      
  
    
      
  
<name content="light">
<style>
  :root {
    color-scheme: light only;
  }
  html, body {
    color-scheme: light only;
  }
</style></name>            </body>
</html>
